//
//  mailcore.h
//  mailcore2
//
//  Created by DINH Viêt Hoà on 1/10/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#ifndef MAILCORE_MAILCORE_H

#define MAILCORE_MAILCORE_H

#include <MailCore/MCCore.h>
#include <MailCore/MCAsync.h>
#include <MailCore/MCObjC.h>

#endif
